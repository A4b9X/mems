// Get saved equipment from the browser
let equipment = JSON.parse(localStorage.getItem("equipment")) || [];
let pmRecords = JSON.parse(localStorage.getItem("pmRecords")) || [];
let cmRecords = JSON.parse(localStorage.getItem("cmRecords")) || [];
// Used when editing a maintenance record
let editingType = null;
let editingIndex = null;

// Show equipment form
function showEquipmentForm() {

    document.getElementById("dashboard").classList.add("hidden");

    document.getElementById("equipmentSection").classList.remove("hidden");

    document.getElementById("equipmentListSection").classList.add("hidden");
}
// Show Preventive Maintenance form

function showPMForm() {

    document.getElementById("dashboard").classList.add("hidden");

    document.getElementById("equipmentSection").classList.add("hidden");

    document.getElementById("equipmentListSection").classList.add("hidden");

    document.getElementById("pmSection").classList.remove("hidden");

    loadEquipmentIntoPMForm();
}
// Show Corrective Maintenance form

function showCMForm() {

    document.getElementById("dashboard").classList.add("hidden");

    document.getElementById("equipmentSection").classList.add("hidden");

    document.getElementById("equipmentListSection").classList.add("hidden");

    document.getElementById("pmSection").classList.add("hidden");

    document.getElementById("cmSection").classList.remove("hidden");

    loadEquipmentIntoCMForm();
}

// Show dashboard
function showDashboard() {

    document.getElementById("equipmentSection").classList.add("hidden");

    document.getElementById("equipmentListSection").classList.add("hidden");

    document.getElementById("pmSection").classList.add("hidden");

    document.getElementById("cmSection").classList.add("hidden");

    document.getElementById("historySection").classList.add("hidden");

    document.getElementById("detailsSection").classList.add("hidden");

    document.getElementById("dashboard").classList.remove("hidden");
}


// Save equipment
document.getElementById("equipmentForm").addEventListener("submit", function(event) {

    event.preventDefault();


    // Get information from the form

    const equipmentData = {

        name: document.getElementById("equipmentName").value,

        assetId: document.getElementById("assetId").value,

        manufacturer: document.getElementById("manufacturer").value,

        model: document.getElementById("model").value,

        department: document.getElementById("department").value,

     equipmentType: document.getElementById("equipmentType").value,

     riskPriority:
    document.getElementById("riskPriority").value,

        frequency: document.getElementById("frequency").value,

        status: document.getElementById("status").value

    };


    // Check that Asset ID is not empty

if (equipmentData.assetId.trim() === "") {

    alert("Asset ID is required.");

    return;

}
// Check for duplicate Asset ID

const existingEquipment = equipment.find(function(item) {

    return item.assetId.toLowerCase() ===
           equipmentData.assetId.trim().toLowerCase();

});

if (existingEquipment) {

    alert("This Asset ID already exists. Please use a unique Asset ID.");

    return;

}


// Add the new equipment to our list

equipment.push(equipmentData);


    // Save the list in the browser

    localStorage.setItem("equipment", JSON.stringify(equipment));


    // Clear the form

    document.getElementById("equipmentForm").reset();


    // Update the dashboard

    updateDashboard();


    // Show success message

    alert("Equipment saved successfully!");


    // Return to dashboard

    showDashboard();

});


// Update dashboard

function updateDashboard() {

    // Total equipment
    document.getElementById("totalEquipment").textContent =
        equipment.length;

    // Total PM records
    document.getElementById("totalPM").textContent =
        pmRecords.length;

    // Total CM records
    document.getElementById("totalCM").textContent =
        cmRecords.length;


    // PM status counters
    let upToDate = 0;
    let dueSoon = 0;
    let overdue = 0;


    // Check every equipment
    equipment.forEach(function(item) {

        const status = getPMStatus(item.assetId);


        if (status === "🟢 Up to Date") {

            upToDate++;

        } else if (status === "🟡 Due Soon") {

            dueSoon++;

        } else if (status === "🔴 Overdue") {

            overdue++;

        }

    });


    // Display PM status numbers
    document.getElementById("upToDateCount").textContent =
        upToDate;

    document.getElementById("dueSoonCount").textContent =
        dueSoon;

    document.getElementById("overdueCount").textContent =
        overdue;

}


// Run when the application opens

updateDashboard();
// Load registered equipment into PM form

function loadEquipmentIntoPMForm() {

    const pmEquipment = document.getElementById("pmEquipment");

    pmEquipment.innerHTML = `
        <option value="">
            Select equipment
        </option>
    `;

    equipment.forEach(function(item) {

        const option = document.createElement("option");

        option.value = item.assetId;

        option.textContent =
            item.name + " - " + item.assetId;

        pmEquipment.appendChild(option);

    });
}
// Save Preventive Maintenance record

document.getElementById("pmForm").addEventListener("submit", function(event) {

    event.preventDefault();


    const pmData = {

        equipmentId:
            document.getElementById("pmEquipment").value,

        date:
            document.getElementById("pmDate").value,

        engineer:
            document.getElementById("engineerName").value,

        visualInspection:
            document.getElementById("visualInspection").checked,

        cleaning:
            document.getElementById("cleaning").checked,

        cableInspection:
            document.getElementById("cableInspection").checked,

        functionalTest:
            document.getElementById("functionalTest").checked,

        electricalTest:
            document.getElementById("electricalTest").checked,

        calibration:
            document.getElementById("calibration").checked,

        spareParts: [
    {
        quantity: document.getElementById("partQuantity1").value,
        partName: document.getElementById("partName1").value,
        partNumber: document.getElementById("partNumber1").value
    },
    {
        quantity: document.getElementById("partQuantity2").value,
        partName: document.getElementById("partName2").value,
        partNumber: document.getElementById("partNumber2").value
    },
    {
        quantity: document.getElementById("partQuantity3").value,
        partName: document.getElementById("partName3").value,
        partNumber: document.getElementById("partNumber3").value
    },
    {
        quantity: document.getElementById("partQuantity4").value,
        partName: document.getElementById("partName4").value,
        partNumber: document.getElementById("partNumber4").value
    }
],

        actions:
            document.getElementById("pmActions").value,

        testResult:
            document.getElementById("pmTestResult").value,

        status:
            document.getElementById("pmStatus").value,

        nextPMDate:
            document.getElementById("nextPMDate").value

    };
// Check that equipment is selected

if (pmData.equipmentId === "") {

    alert("Please select equipment.");

    return;

}
// Check that PM date is entered

if (pmData.date === "") {

    alert("Please enter the maintenance date.");

    return;

}

// Check that engineer name is entered

if (pmData.engineer.trim() === "") {

    alert("Please enter the engineer / technician name.");

    return;

}

// Check that Next PM Date is entered

if (pmData.nextPMDate === "") {

    alert("Please enter the next PM date.");

    return;

}


// Check that Next PM Date is not before PM Date

if (new Date(pmData.nextPMDate) < new Date(pmData.date)) {

    alert("Next PM Date cannot be earlier than the maintenance date.");

    return;

}

    // Check whether we are editing an existing record

if (
    editingType === "Preventive Maintenance" &&
    editingIndex !== null
) {

    pmRecords[editingIndex] = pmData;

} else {

    pmRecords.push(pmData);

}


// Save PM records

localStorage.setItem(
    "pmRecords",
    JSON.stringify(pmRecords)
);


// Reset editing mode

editingType = null;
editingIndex = null;


    document.getElementById("pmForm").reset();


    updateDashboard();


    alert("Preventive Maintenance record saved successfully!");


    showDashboard();

});
function loadEquipmentIntoCMForm() {

    const cmEquipment = document.getElementById("cmEquipment");

    cmEquipment.innerHTML = `
        <option value="">
            Select equipment
        </option>
    `;

    equipment.forEach(function(item) {

        const option = document.createElement("option");

        option.value = item.assetId;

        option.textContent =
            item.name + " - " + item.assetId;

        cmEquipment.appendChild(option);

    });
}


// SAVE CORRECTIVE MAINTENANCE RECORD

document.getElementById("cmForm").addEventListener("submit", function(event) {

    event.preventDefault();

    const cmData = {

        equipmentId: document.getElementById("cmEquipment").value,

        date: document.getElementById("cmDate").value,

        engineer: document.getElementById("cmEngineer").value,

        reportedProblem: document.getElementById("reportedProblem").value,

        faultCause: document.getElementById("faultCause").value,

        correctiveAction: document.getElementById("correctiveAction").value,

        partsReplaced: document.getElementById("partsReplaced").value,

        testResult: document.getElementById("cmTestResult").value,

        status: document.getElementById("cmStatus").value,

        remarks: document.getElementById("cmRemarks").value

    };
// Check that equipment is selected

if (cmData.equipmentId === "") {

    alert("Please select equipment.");

    return;

}
// Check that CM date is entered

if (cmData.date === "") {

    alert("Please enter the maintenance date.");

    return;

}
// Check that engineer name is entered

if (cmData.engineer.trim() === "") {

    alert("Please enter the engineer / technician name.");

    return;

}
// Check that reported problem is entered

if (cmData.reportedProblem.trim() === "") {

    alert("Please describe the reported problem.");

    return;

}
// Check that fault / cause is entered

if (cmData.faultCause.trim() === "") {

    alert("Please describe the observed fault / cause.");

    return;

}
  // Check whether we are editing an existing CM record

if (
    editingType === "Corrective Maintenance" &&
    editingIndex !== null
) {

    cmRecords[editingIndex] = cmData;

} else {

    cmRecords.push(cmData);

}


// Save CM records

localStorage.setItem(
    "cmRecords",
    JSON.stringify(cmRecords)
);


// Reset editing mode

editingType = null;
editingIndex = null;

    document.getElementById("cmForm").reset();

    updateDashboard();

    alert("Corrective Maintenance record saved successfully!");

    showDashboard();

});

// Show Maintenance History

function showHistory() {

    document.getElementById("dashboard").classList.add("hidden");

    document.getElementById("equipmentSection").classList.add("hidden");

    document.getElementById("equipmentListSection").classList.add("hidden");

    document.getElementById("pmSection").classList.add("hidden");

    document.getElementById("cmSection").classList.add("hidden");

    document.getElementById("detailsSection").classList.add("hidden");

    document.getElementById("historySection").classList.remove("hidden");

    displayMaintenanceHistory();
}
// Display Maintenance History

function displayMaintenanceHistory() {

    const historyList = document.getElementById("historyList");

    historyList.innerHTML = "";

    // Display PM records
    pmRecords.forEach(function(record, index) {

        const equipmentItem = equipment.find(function(eq) {
            return eq.assetId === record.equipmentId;
        });

        let equipmentName = "Unknown Equipment";

        if (equipmentItem) {
            equipmentName =
                equipmentItem.name +
                " - " +
                equipmentItem.assetId;
        }

        const historyRecord =
            document.createElement("div");

        historyRecord.className = "history-record";

        historyRecord.innerHTML = `

            <h3>Preventive Maintenance</h3>

            <p>
                <strong>Equipment:</strong>
                ${equipmentName}
            </p>

            <p>
                <strong>Date:</strong>
                ${record.date}
            </p>

            <p>
                <strong>Engineer:</strong>
                ${record.engineer}
            </p>

            <p>
                <strong>Status:</strong>
                ${record.status}
            </p>

            <button
                class="details-button"
                onclick="viewRecordDetails('Preventive Maintenance', ${index})"
            >
                View Details
            </button>
            <button
    class="edit-button"
    onclick="editMaintenanceRecord('Preventive Maintenance', ${index})"
>
    Edit
</button>

            <button
                class="delete-button"
                onclick="deleteMaintenanceRecord('Preventive Maintenance', ${index})"
            >
                Delete
            </button>

        `;

        historyList.appendChild(historyRecord);

    });


    // Display CM records
    cmRecords.forEach(function(record, index) {

        const equipmentItem = equipment.find(function(eq) {
            return eq.assetId === record.equipmentId;
        });

        let equipmentName = "Unknown Equipment";

        if (equipmentItem) {
            equipmentName =
                equipmentItem.name +
                " - " +
                equipmentItem.assetId;
        }

        const historyRecord =
            document.createElement("div");

        historyRecord.className = "history-record";

        historyRecord.innerHTML = `

            <h3>Corrective Maintenance</h3>

            <p>
                <strong>Equipment:</strong>
                ${equipmentName}
            </p>

            <p>
                <strong>Date:</strong>
                ${record.date}
            </p>

            <p>
                <strong>Engineer:</strong>
                ${record.engineer}
            </p>

            <p>
                <strong>Status:</strong>
                ${record.status}
            </p>

            <button
                class="details-button"
                onclick="viewRecordDetails('Corrective Maintenance', ${index})"
            >
                View Details
            </button>
           <button
    class="edit-button"
    onclick="editMaintenanceRecord('Corrective Maintenance', ${index})"
>
    Edit
</button> 

            <button
                class="delete-button"
                onclick="deleteMaintenanceRecord('Corrective Maintenance', ${index})"
            >
                Delete
            </button>

        `;

        historyList.appendChild(historyRecord);

    });


    // Check if there are no records

    if (
        pmRecords.length === 0 &&
        cmRecords.length === 0
    ) {

        historyList.innerHTML = `
            <p>No maintenance records available.</p>
        `;

    }

}
// View full maintenance record

function viewRecordDetails(type, index) {

    document.getElementById("dashboard").classList.add("hidden");

    document.getElementById("equipmentSection").classList.add("hidden");

    document.getElementById("equipmentListSection").classList.add("hidden");

    document.getElementById("pmSection").classList.add("hidden");

    document.getElementById("cmSection").classList.add("hidden");

    document.getElementById("historySection").classList.add("hidden");

    document.getElementById("detailsSection").classList.remove("hidden");


    let record;

    if (type === "Preventive Maintenance") {

        record = pmRecords[index];

    } else {

        record = cmRecords[index];

    }


    const equipmentItem = equipment.find(function(eq) {

        return eq.assetId === record.equipmentId;

    });


    let equipmentName = "Unknown Equipment";

    if (equipmentItem) {

        equipmentName =
            equipmentItem.name +
            " - " +
            equipmentItem.assetId;

    }


    document.getElementById("detailsTitle").textContent =
        type + " Details";


    let detailsHTML = `

        <div class="details-content">

            <h3>Equipment Information</h3>

            <p>
                <strong>Equipment:</strong>
                ${equipmentName}
            </p>

            <p>
                <strong>Date:</strong>
                ${record.date}
            </p>

            <p>
                <strong>Engineer / Technician:</strong>
                ${record.engineer}
            </p>

    `;


    if (type === "Preventive Maintenance") {

        detailsHTML += `

            <h3>Maintenance Checklist</h3>

            <p>
                <strong>Visual Inspection:</strong>
                ${record.visualInspection ? "Completed" : "Not Completed"}
            </p>

            <p>
                <strong>Cleaning:</strong>
                ${record.cleaning ? "Completed" : "Not Completed"}
            </p>

            <p>
                <strong>Cable / Connection Inspection:</strong>
                ${record.cableInspection ? "Completed" : "Not Completed"}
            </p>

            <p>
                <strong>Functional Test:</strong>
                ${record.functionalTest ? "Completed" : "Not Completed"}
            </p>

            <p>
                <strong>Electrical Safety Test:</strong>
                ${record.electricalTest ? "Completed" : "Not Completed"}
            </p>

            <p>
                <strong>Calibration:</strong>
                ${record.calibration ? "Completed" : "Not Completed"}
            </p>

           <h3>Spare Parts Replaced, if any</h3>

<table class="spare-parts-table">
    <thead>
        <tr>
            <th>No.</th>
            <th>Quantity</th>
            <th>Part Name</th>
            <th>Part Number</th>
        </tr>
    </thead>

    <tbody>
        ${
            record.spareParts && record.spareParts.length > 0
            ? record.spareParts.map(function(part, index) {
                return `
                    <tr>
                        <td>${index + 1}</td>
                        <td>${part.quantity || ""}</td>
                        <td>${part.partName || ""}</td>
                        <td>${part.partNumber || ""}</td>
                    </tr>
                `;
            }).join("")
            : `
                <tr>
                    <td colspan="4">No spare parts replaced</td>
                </tr>
            `
        }
    </tbody>
</table>
            <p>
                <strong>Actions Performed:</strong>
                ${record.actions}
            </p>

            <h3>Result</h3>

            <p>
                <strong>Test Result:</strong>
                ${record.testResult}
            </p>

            <p>
                <strong>Equipment Status:</strong>
                ${record.status}
            </p>

            <p>
                <strong>Next PM Date:</strong>
                ${record.nextPMDate}
            </p>

        `;

    } else {

        detailsHTML += `

            <h3>Problem Information</h3>

            <p>
                <strong>Reported Problem:</strong>
                ${record.reportedProblem}
            </p>

            <p>
                <strong>Observed Fault / Cause:</strong>
                ${record.faultCause}
            </p>

            <h3>Corrective Action</h3>

            <p>
                <strong>Action Performed:</strong>
                ${record.correctiveAction}
            </p>

            <p>
                <strong>Parts / Materials Used:</strong>
                ${record.partsReplaced}
            </p>

            <h3>Result</h3>

            <p>
                <strong>Functional Test:</strong>
                ${record.testResult}
            </p>

            <p>
                <strong>Final Equipment Status:</strong>
                ${record.status}
            </p>

            <p>
                <strong>Remarks:</strong>
                ${record.remarks || "None"}
            </p>

        `;

    }


    detailsHTML += `

        </div>

    `;


    document.getElementById("detailsContent").innerHTML =
        detailsHTML;

}
// Show Equipment List

function showEquipmentList() {

    document.getElementById("dashboard").classList.add("hidden");

    document.getElementById("equipmentSection").classList.add("hidden");

    document.getElementById("pmSection").classList.add("hidden");

    document.getElementById("cmSection").classList.add("hidden");

    document.getElementById("historySection").classList.add("hidden");

    document.getElementById("detailsSection").classList.add("hidden");

    document.getElementById("equipmentListSection").classList.remove("hidden");

    displayEquipmentList();
}
// Display registered equipment

function displayEquipmentList() {

    const equipmentList =
        document.getElementById("equipmentList");

    equipmentList.innerHTML = "";


    if (equipment.length === 0) {

        equipmentList.innerHTML = `
            <p>No equipment has been registered yet.</p>
        `;

        return;
    }


    equipment.forEach(function(item) {

        const equipmentRecord =
            document.createElement("div");

        equipmentRecord.className =
            "equipment-record";


        equipmentRecord.innerHTML = `

            <h3>
                ${item.name}
            </h3>

            <p>
                <strong>Asset ID:</strong>
                ${item.assetId}
            </p>

            <p>
                <strong>Manufacturer:</strong>
                ${item.manufacturer}
            </p>

            <p>
                <strong>Model:</strong>
                ${item.model}
            </p>

            <p>
                <strong>Department:</strong>
                ${item.department}
            </p>

            <p>
                <strong>Equipment Type:</strong>
${item.equipmentType}
            </p>
<p>
    <strong>Risk Priority:</strong>
    ${item.riskPriority}
</p>
            <p>
                <strong>PM Frequency:</strong>
                ${item.frequency}
            </p>

            <p>
                <strong>Status:</strong>
                ${item.status}
            </p>
            <p>
    <strong>Last PM:</strong>
    ${getLastPMDate(item.assetId)}
</p>

<p>
    <strong>Next PM:</strong>
    ${getNextPMDate(item.assetId)}
</p>

<p>
    <strong>PM Status:</strong>
    ${getPMStatus(item.assetId)}
</p>
            <button
    type="button"
    onclick="editEquipment('${item.assetId}')"
>
    Edit
</button>
<button
    type="button"
    onclick="deleteEquipment('${item.assetId}')"
>
    Delete
</button>

        `;


        equipmentList.appendChild(equipmentRecord);

    });

}
// Search equipment

function searchEquipment() {

    const searchText =
        document.getElementById("equipmentSearch")
        .value
        .toLowerCase()
        .trim();

    const equipmentRecords =
        document.querySelectorAll(".equipment-record");

    equipmentRecords.forEach(function(record) {

        const recordText =
            record.textContent.toLowerCase();

        if (recordText.includes(searchText)) {

            record.style.display = "block";

        } else {

            record.style.display = "none";

        }

    });

    // Check if any equipment is visible
    const visibleRecords =
        Array.from(equipmentRecords).filter(function(record) {
            return record.style.display !== "none";
        });

    const equipmentList =
        document.getElementById("equipmentList");

    const existingMessage =
        document.getElementById("noEquipmentMessage");

    if (visibleRecords.length === 0) {

        if (!existingMessage) {
            equipmentList.insertAdjacentHTML(
                "beforeend",
                `<p id="noEquipmentMessage">No matching equipment found.</p>`
            );
        }

    } else {

        if (existingMessage) {
            existingMessage.remove();
        }

    }

}

function editEquipment(assetId) {

    const item = equipment.find(function(eq) {

        return eq.assetId === assetId;

    });


    if (!item) {

        alert("Equipment not found.");

        return;

    }


    const newName = prompt(
        "Equipment Name:",
        item.name
    );


    if (newName === null) {

        return;

    }


    const newManufacturer = prompt(
        "Manufacturer:",
        item.manufacturer
    );


    if (newManufacturer === null) {

        return;

    }


    const newModel = prompt(
        "Model:",
        item.model
    );


    if (newModel === null) {

        return;

    }


    const newDepartment = prompt(
        "Department:",
        item.department
    );


    if (newDepartment === null) {

        return;

    }


    const newEquipmentType = prompt(
    "Equipment Type:",
    item.equipmentType
);


    if (newLocation === null) {

        return;

    }
const newFrequency = prompt(
    "PM Frequency:",
    item.frequency
);

if (newFrequency === null) {

    return;

}


const newStatus = prompt(
    "Status:",
    item.status
);

if (newStatus === null) {

    return;

}
if (
    newName.trim() === "" ||
    newManufacturer.trim() === "" ||
    newModel.trim() === "" ||
    newDepartment.trim() === "" ||
    newEquipmentType.trim() === "" ||
    newFrequency.trim() === "" ||
    newStatus.trim() === ""
) {

    alert("Please fill in all equipment information.");

    return;

}

  item.name = newName.trim();

item.manufacturer = newManufacturer.trim();

item.model = newModel.trim();

item.department = newDepartment.trim();

item.equipmentType = newEquipmentType.trim();

item.frequency = newFrequency.trim();

item.status = newStatus.trim();


    localStorage.setItem(
        "equipment",
        JSON.stringify(equipment)
    );


    displayEquipmentList();


    alert("Equipment updated successfully!");

}
// Delete equipment safely

function deleteEquipment(assetId) {

    const item = equipment.find(function(eq) {
        return eq.assetId === assetId;
    });

    if (!item) {
        alert("Equipment not found.");
        return;
    }

   const confirmDelete = confirm(
    "Are you sure you want to delete " +
    item.name +
    " (" +
    item.assetId +
    ")?\n\n" +
    "The equipment will be removed from the Registered Equipment list, " +
    "but its maintenance history will be kept."
);

    if (!confirmDelete) {
        return;
    }

    equipment = equipment.filter(function(eq) {
        return eq.assetId !== assetId;
    });

    localStorage.setItem(
        "equipment",
        JSON.stringify(equipment)
    );

    displayEquipmentList();

    updateDashboard();

    alert("Equipment deleted successfully!");
}
// Get the last PM date for an equipment

function getLastPMDate(assetId) {

    const records = pmRecords.filter(function(record) {
        return record.equipmentId === assetId;
    });

    if (records.length === 0) {
        return "No PM recorded";
    }

    records.sort(function(a, b) {
        return new Date(b.date) - new Date(a.date);
    });

    return records[0].date;
}
// Get the next PM date for an equipment

function getNextPMDate(assetId) {

    const records = pmRecords.filter(function(record) {
        return record.equipmentId === assetId;
    });

    if (records.length === 0) {
        return "Not scheduled";
    }

    records.sort(function(a, b) {
        return new Date(b.date) - new Date(a.date);
    });

    return records[0].nextPMDate || "Not scheduled";
}
// Check PM status

function getPMStatus(assetId) {

    const records = pmRecords.filter(function(record) {
        return record.equipmentId === assetId;
    });

    if (records.length === 0) {
        return "No PM recorded";
    }

    records.sort(function(a, b) {
        return new Date(b.date) - new Date(a.date);
    });

    const nextDate = records[0].nextPMDate;

    if (!nextDate) {
        return "Not scheduled";
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const pmDate = new Date(nextDate);
    pmDate.setHours(0, 0, 0, 0);

    const difference =
        (pmDate - today) / (1000 * 60 * 60 * 24);

    if (difference < 0) {
        return "🔴 Overdue";
    }

    if (difference <= 30) {
        return "🟡 Due Soon";
    }

    return "🟢 Up to Date";
}
function clearHistorySearch() {
    document.getElementById("historySearch").value = "";
    searchMaintenanceHistory();
}
// Search and filter maintenance history

function searchMaintenanceHistory() {

    const searchText = document
        .getElementById("historySearch")
        .value
        .toLowerCase()
        .trim();

    const selectedType =
        document.getElementById("historyTypeFilter").value;

    const historyRecords =
        document.querySelectorAll(".history-record");

    historyRecords.forEach(function(record) {

        const recordText =
            record.textContent.toLowerCase();

        const recordType =
            record.querySelector("h3").textContent.trim();

        const matchesSearch =
            recordText.includes(searchText);

        const matchesType =
            selectedType === "All" ||
            recordType === selectedType;

        if (matchesSearch && matchesType) {

            record.style.display = "";

        } else {

            record.style.display = "none";

        }

    });
    // Check if any records are visible

const visibleRecords =
    Array.from(historyRecords).filter(function(record) {

        return record.style.display !== "none";

    });

const historyList =
    document.getElementById("historyList");

const existingMessage =
    document.getElementById("noHistoryMessage");

if (visibleRecords.length === 0) {

    if (!existingMessage) {

        historyList.insertAdjacentHTML(
            "beforeend",
            `<p id="noHistoryMessage">No matching maintenance records found.</p>`
        );

    }

} else {

    if (existingMessage) {

        existingMessage.remove();

    }

}

}
// Apply the maintenance history filter

function filterMaintenanceHistory() {

    searchMaintenanceHistory();

}
function deleteMaintenanceRecord(type, index) {

    const confirmDelete = confirm(
        "Are you sure you want to delete this maintenance record?"
    );

    if (!confirmDelete) {
        return;
    }


    // Delete from the correct record array

    if (type === "Preventive Maintenance") {

        if (index < 0 || index >= pmRecords.length) {
            alert("Unable to delete this PM record.");
            return;
        }

        pmRecords.splice(index, 1);

        localStorage.setItem(
            "pmRecords",
            JSON.stringify(pmRecords)
        );

    } else if (type === "Corrective Maintenance") {

        if (index < 0 || index >= cmRecords.length) {
            alert("Unable to delete this CM record.");
            return;
        }

        cmRecords.splice(index, 1);

        localStorage.setItem(
            "cmRecords",
            JSON.stringify(cmRecords)
        );

    } else {

        alert("Unknown maintenance record type.");
        return;

    }


    // Update dashboard

    updateDashboard();


    // Refresh maintenance history

    displayMaintenanceHistory();


    alert("Maintenance record deleted successfully!");

}
// Edit a maintenance record

function editMaintenanceRecord(type, index) {

    editingType = type;
    editingIndex = index;


    // Edit Preventive Maintenance record

    if (type === "Preventive Maintenance") {

        const record = pmRecords[index];

        document.getElementById("historySection").classList.add("hidden");
        document.getElementById("pmSection").classList.remove("hidden");

       // Load equipment into PM dropdown

const pmEquipmentSelect =
    document.getElementById("pmEquipment");

pmEquipmentSelect.innerHTML = `
    <option value="">Select equipment</option>
`;

equipment.forEach(function(eq) {

    const option = document.createElement("option");

    option.value = eq.assetId;

    option.textContent =
        eq.name + " - " + eq.assetId;

    pmEquipmentSelect.appendChild(option);

});


// Select the equipment used by this record

pmEquipmentSelect.value =
    record.equipmentId;

        document.getElementById("pmDate").value =
            record.date;

        document.getElementById("engineerName").value =
            record.engineer;

        document.getElementById("visualInspection").checked =
            record.visualInspection;

        document.getElementById("cleaning").checked =
            record.cleaning;

        document.getElementById("cableInspection").checked =
            record.cableInspection;

        document.getElementById("functionalTest").checked =
            record.functionalTest;

        document.getElementById("electricalTest").checked =
            record.electricalTest;

        document.getElementById("calibration").checked =
            record.calibration;

       if (record.spareParts) {
    record.spareParts.forEach(function(part, index) {
        const rowNumber = index + 1;

        document.getElementById("partQuantity" + rowNumber).value =
            part.quantity || "";

        document.getElementById("partName" + rowNumber).value =
            part.partName || "";

        document.getElementById("partNumber" + rowNumber).value =
            part.partNumber || "";
    });
}

        document.getElementById("pmActions").value =
            record.actions;

        document.getElementById("pmTestResult").value =
            record.testResult;

        document.getElementById("pmStatus").value =
            record.status;

        document.getElementById("nextPMDate").value =
            record.nextPMDate;

        return;
    }


    // Edit Corrective Maintenance record

    if (type === "Corrective Maintenance") {

        const record = cmRecords[index];

        document.getElementById("historySection").classList.add("hidden");
        document.getElementById("cmSection").classList.remove("hidden");

        // Load equipment into CM dropdown

const cmEquipmentSelect =
    document.getElementById("cmEquipment");

cmEquipmentSelect.innerHTML = `
    <option value="">Select equipment</option>
`;

equipment.forEach(function(eq) {

    const option = document.createElement("option");

    option.value = eq.assetId;

    option.textContent =
        eq.name + " - " + eq.assetId;

    cmEquipmentSelect.appendChild(option);

});


// Select the equipment used by this record

cmEquipmentSelect.value =
    record.equipmentId;

        document.getElementById("cmDate").value =
            record.date;

        document.getElementById("cmEngineer").value =
            record.engineer;

        document.getElementById("reportedProblem").value =
            record.reportedProblem;

        document.getElementById("faultCause").value =
            record.faultCause;

        document.getElementById("correctiveAction").value =
            record.correctiveAction;

        document.getElementById("partsReplaced").value =
            record.partsReplaced;

        document.getElementById("cmTestResult").value =
            record.testResult;

        document.getElementById("cmStatus").value =
            record.status;

        document.getElementById("cmRemarks").value =
            record.remarks || "";

    }

}
// Print maintenance record

function printMaintenanceRecord() {

    window.print();

}